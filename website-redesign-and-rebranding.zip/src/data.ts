import coverHorizon from "./assets/cover-horizon.jpg";
import coverMinuitDore from "./assets/cover-minuit-dore.jpg";
import coverPulsar from "./assets/cover-pulsar.jpg";
import coverVelvetNoir from "./assets/cover-velvet-noir.jpg";
import {
  AudioWaveform,
  MessageSquareText,
  Repeat2,
  Rocket,
  type LucideIcon,
} from "lucide-react";

export const NAV_LINKS = [
  { label: "Services", href: "#services" },
  { label: "Sons", href: "#sons" },
  { label: "Immersion", href: "#immersion" },
  { label: "Studio", href: "#studio" },
  { label: "Processus", href: "#processus" },
  { label: "Contact", href: "#contact" },
];

export const HERO_IMAGE =
  "https://images.pexels.com/photos/30807699/pexels-photo-30807699.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1080&w=1920";

export const STUDIO_IMAGE =
  "https://images.pexels.com/photos/5749191/pexels-photo-5749191.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=960";

export const MARQUEE_ITEMS = [
  "Production de beats",
  "Mix & mastering",
  "Sound design",
  "Direction artistique",
  "Topline",
  "Identité sonore",
];

export const SERVICES = [
  {
    id: "01",
    title: "Production de beats",
    description:
      "Des instrumentals qui claquent et qui racontent. Chaque beat est une signature, pas une boucle de plus.",
    tags: ["Afrotrap", "Drill", "R&B", "Pop"],
    image:
      "https://images.pexels.com/photos/5749192/pexels-photo-5749192.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: "02",
    title: "Mix & mastering",
    description:
      "Un son propre, large et percutant, pensé pour briller sur toutes les plateformes comme en club.",
    tags: ["Stems", "Radio-ready", "Club", "Streaming"],
    image:
      "https://images.pexels.com/photos/8197361/pexels-photo-8197361.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: "03",
    title: "Sound design",
    description:
      "Textures, ambiances et identités sonores sur-mesure pour des morceaux qu'on reconnaît en trois secondes.",
    tags: ["Textures", "Ambiances", "Identité sonore", "Habillage"],
    image:
      "https://images.pexels.com/photos/30807710/pexels-photo-30807710.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
  {
    id: "04",
    title: "Direction artistique",
    description:
      "Une vision globale : choix des sons, structuration, image et stratégie de sortie pour chaque projet.",
    tags: ["Vision", "Stratégie", "Image", "Sortie"],
    image:
      "https://images.pexels.com/photos/18464243/pexels-photo-18464243.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  },
];

export const TRACKS = [
  {
    title: "Minuit Doré",
    genre: "Afrotrap",
    bpm: 140,
    duration: "3:12",
    cover: coverMinuitDore,
  },
  {
    title: "Velvet Noir",
    genre: "R&B alternatif",
    bpm: 92,
    duration: "3:47",
    cover: coverVelvetNoir,
  },
  {
    title: "Horizon",
    genre: "Drill mélodique",
    bpm: 144,
    duration: "2:58",
    cover: coverHorizon,
  },
  {
    title: "Pulsar",
    genre: "Électro",
    bpm: 128,
    duration: "3:21",
    cover: coverPulsar,
  },
];

export const STATS = [
  { value: 120, suffix: "+", label: "Beats produits" },
  { value: 40, suffix: "+", label: "Artistes accompagnés" },
  { value: 8, suffix: " ans", label: "De craft" },
  { value: 12, suffix: "M+", label: "Streams générés" },
];

export const PROCESS: {
  n: string;
  title: string;
  desc: string;
  icon: LucideIcon;
}[] = [
  {
    n: "01",
    title: "Brief & vision",
    desc: "On écoute, on comprend, on cadre. Tes références, ton univers, ton ambition — rien ne se perd.",
    icon: MessageSquareText,
  },
  {
    n: "02",
    title: "Création",
    desc: "Premières démos sous 48h. Le beat prend forme, la vision devient son, l'idée devient hymne.",
    icon: AudioWaveform,
  },
  {
    n: "03",
    title: "Itérations",
    desc: "On affine ensemble, sans limite de compteur. Chaque retouche sert le morceau, jamais l'ego.",
    icon: Repeat2,
  },
  {
    n: "04",
    title: "Livraison & suivi",
    desc: "Stems, mix, master, accompagnement sortie. Tu repars avec un son prêt à marquer les esprits.",
    icon: Rocket,
  },
];

export const TESTIMONIALS = [
  {
    quote:
      "Elgor a transformé ma maquette en un morceau signé. Le mix claque, la vision est claire, l'exécution impeccable.",
    name: "Lina M.",
    role: "Artiste R&B — Paris",
  },
  {
    quote:
      "Un vrai partenaire créatif. Chaque beat raconte une histoire, chaque retouche sert le morceau.",
    name: "Karim B.",
    role: "Rappeur — Bruxelles",
  },
  {
    quote:
      "Le passage de Elgor-Beatz à Creati'v Hub n'a rien changé au feu. Ça l'a amplifié.",
    name: "Studio Halogène",
    role: "Label indépendant",
  },
];

export const SOCIALS = [
  { label: "Instagram", href: "https://instagram.com" },
  { label: "YouTube", href: "https://youtube.com" },
  { label: "X / Twitter", href: "https://x.com" },
];
