import { motion } from "framer-motion";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { HERO_IMAGE } from "../data";
import { Waveform } from "./Waveform";

const EASE: [number, number, number, number] = [0.22, 1, 0.36, 1];

function Line({ children, delay }: { children: React.ReactNode; delay: number }) {
  return (
    <div className="overflow-hidden">
      <motion.div
        initial={{ y: "110%" }}
        animate={{ y: 0 }}
        transition={{ duration: 1, delay, ease: EASE }}
      >
        {children}
      </motion.div>
    </div>
  );
}

export function Hero() {
  return (
    <section id="top" className="relative flex min-h-svh flex-col overflow-hidden">
      <div className="absolute inset-0">
        <motion.img
          src={HERO_IMAGE}
          alt="Studio d'enregistrement Elgor Creati'v Hub"
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.45 }}
          transition={{ duration: 2.6, ease: EASE }}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/92 via-ink/40 to-ink" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/80 via-transparent to-ink/60" />
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col justify-center px-5 pb-14 pt-40 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.4, ease: EASE }}
          className="mb-10 inline-flex w-fit items-center gap-2 rounded-full border border-gold/30 bg-ink/70 px-5 py-2 backdrop-blur"
        >
          <span className="text-[10px] font-medium uppercase tracking-[0.3em] text-cream/70">
            Studio créatif
          </span>
        </motion.div>

        <h1 className="font-display font-black uppercase leading-[0.82] tracking-[-0.02em]">
          <Line delay={1.5}>
            <span className="block font-expanded text-[clamp(3.4rem,12vw,9.5rem)] leading-none">
              ELGOR
            </span>
          </Line>
          <Line delay={1.65}>
            <span className="mt-1 block font-semi-expanded text-[clamp(1.6rem,5.5vw,4.2rem)] leading-[0.95] text-gold">
              Creati'v Hub
            </span>
          </Line>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.95, ease: EASE }}
          className="mt-8 max-w-xl text-base leading-relaxed text-cream/70 md:text-lg"
        >
          Production de beats, mix & mastering, sound design et direction
          artistique. Un studio pour les artistes qui exigent la excellence.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 2.1, ease: EASE }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <a
            href="#sons"
            className="group inline-flex items-center gap-2.5 bg-gold px-7 py-4 font-display text-sm font-bold uppercase tracking-widest text-ink transition-colors hover:bg-gold-soft"
          >
            Écouter les sons
            <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2.5 border border-cream/25 px-7 py-4 font-display text-sm font-bold uppercase tracking-widest text-cream transition-colors hover:border-gold hover:text-gold"
          >
            Réserver une session
          </a>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.2, delay: 2.3 }}
        className="relative z-10 border-t border-cream/10"
      >
        <div className="mx-auto flex max-w-7xl items-end justify-between gap-10 px-5 py-6 md:px-8">
          <Waveform className="h-8 flex-1 opacity-70" bars={48} />
          <a
            href="#services"
            className="hidden items-center gap-2 text-[10px] font-medium uppercase tracking-[0.3em] text-sand transition-colors hover:text-gold md:flex"
          >
            Descendre
            <ArrowDown className="h-3.5 w-3.5 animate-bounce" />
          </a>
        </div>
      </motion.div>
    </section>
  );
}
