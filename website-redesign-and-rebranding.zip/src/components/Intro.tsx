import { motion } from "framer-motion";

export function Intro() {
  return (
    <motion.div
      className="pointer-events-none fixed inset-0 z-[100] flex flex-col items-center justify-center bg-ink"
      initial={{ y: 0 }}
      animate={{ y: "-100%" }}
      transition={{ duration: 0.85, delay: 1.55, ease: [0.76, 0, 0.24, 1] }}
    >
      {/* --- Monogramme EB --- */}
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="w-[clamp(140px,22vw,230px)]"
      >
        <svg
          viewBox="0 0 338 220"
          className="w-full text-cream"
          fill="currentColor"
          aria-hidden="true"
        >
          <motion.rect
            x="0"
            y="0"
            width="130"
            height="220"
            fill="currentColor"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.5 }}
          />
          <motion.path
            d="M0 0H130V42H70V89H112V131H70V178H130V220H0Z"
            fill="currentColor"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.5 }}
          />
          {[142, 151, 160, 169].map((x, i) => (
            <motion.rect
              key={x}
              x={x}
              width="4"
              height="220"
              fill="currentColor"
              initial={{ scaleY: 0 }}
              animate={{ scaleY: 1 }}
              transition={{
                delay: 0.3 + i * 0.07,
                duration: 0.5,
                ease: [0.22, 1, 0.36, 1],
              }}
              style={{ transformOrigin: "top" }}
            />
          ))}
          <motion.path
            fillRule="evenodd"
            clipRule="evenodd"
            d="M182 0H256C298 0 326 20 326 55C326 88 300 108 264 110C308 112 338 136 338 168C338 202 306 220 258 220H182V0ZM236 40H256C276 40 288 48 288 65C288 82 276 90 256 90H236V40ZM236 130H258C280 130 294 138 294 155C294 172 280 180 258 180H236V130Z"
            fill="currentColor"
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.55, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          />
        </svg>
      </motion.div>

      {/* --- Point doré signature --- */}
      <motion.span
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.85, duration: 0.45, ease: "backOut" }}
        className="mt-9 h-3 w-3 rounded-full bg-gold"
      />

      {/* --- Wordmark --- */}
      <div className="mt-7 overflow-hidden px-6 text-center">
        <motion.p
          initial={{ y: "110%" }}
          animate={{ y: 0 }}
          transition={{ duration: 0.7, delay: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="font-display text-2xl font-black font-expanded uppercase leading-none tracking-tight md:text-4xl"
        >
          Elgor Creati'v Hub
        </motion.p>
      </div>

      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 1.2, delay: 0.2, ease: "easeInOut" }}
        className="absolute bottom-0 left-0 h-[3px] w-full origin-left bg-gold"
      />
    </motion.div>
  );
}
