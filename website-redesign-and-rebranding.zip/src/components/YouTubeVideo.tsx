type YouTubeVideoProps = {
  id: string;
  title: string;
  desc: string;
  n: number;
};

export function YouTubeVideo({ id, title, desc, n }: YouTubeVideoProps) {
  const [active, setActive] = useState(false);

  return (
    <article
      className="relative aspect-video overflow-hidden rounded-xl border border-line bg-ink transition-all duration-500 hover:border-gold/40"
      onClick={() => setActive(true)}
    >
      {/* Miniature YouTube */}
      <img
        src={`https://img.youtube.com/vi/${id}/maxresdefault.jpg`}
        alt={title}
        loading="lazy"
        className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-ink/60 transition-opacity duration-300 group-hover:opacity-0" />

      {/* Bouton play immersif */}
      <div
        className="absolute inset-0 flex items-center justify-center opacity-100 transition-opacity duration-300 group-hover:opacity-0"
      >
        <div className="relative flex items-center gap-3 px-6 py-3 rounded-full bg-gold text-ink">
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-ink text-gold shadow-[0_0_40px_rgba(232,163,61,0.45)]"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 ml-0.5"
            >
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
          </motion.div>
          <span className="font-display text-sm font-bold tracking-widest">
            Lire la session
          </span>
        </div>
      </div>

      {/* Infos en bas */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent">
        <span className="block text-[10px] font-medium uppercase tracking-[0.3em] text-gold">
          Session {n}
        </span>
        <h3 className="mt-1 font-display text-lg font-bold tracking-tight">{title}</h3>
        <p className="mt-1 text-xs text-sand/80">{desc}</p>
      </div>

      {/* Iframe YouTube injectée au clic */}
      {active && (
        <div className="absolute inset-0 z-10 bg-ink">
          <iframe
            className="h-full w-full"
            src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&modestbranding=1&rel=0&showinfo=0&fs=0`}
            title={title}
            allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            loading="lazy"
          />
          <button
            onClick={() => setActive(false)}
            className="absolute top-4 right-4 h-10 w-10 rounded-full border border-gold/40 bg-ink/80 text-gold hover:bg-gold hover:text-ink transition-colors z-20"
            aria-label="Fermer la vidéo"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5">
              <line x1="18" x2="6" y1="6" y2="18" />
              <line x1="6" x2="18" y1="6" y2="18" />
            </svg>
          </button>
        </div>
      )}
    </article>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
