import { motion } from "framer-motion";
import { ArrowUpRight, Mail } from "lucide-react";
import { Reveal, SectionLabel } from "./Reveal";
import { Waveform } from "./Waveform";

export function CTA() {
  return (
    <section
      id="contact"
      className="relative overflow-hidden border-t border-line py-28 text-center md:py-40"
    >
      <div className="absolute inset-x-0 bottom-0 flex justify-center opacity-15">
        <Waveform className="h-14 w-full max-w-4xl" bars={56} />
      </div>

      <div className="relative z-10 mx-auto max-w-5xl px-5 md:px-8">
        <Reveal className="mb-10 flex justify-center">
          <SectionLabel index="06" label="Contact" />
        </Reveal>

        <Reveal delay={0.1}>
          <h2 className="mt-8 font-display font-black font-expanded uppercase leading-[0.88] tracking-[-0.02em] text-[clamp(2.8rem,10vw,7.5rem)]">
            Prêt à créer ?
          </h2>
        </Reveal>

        <Reveal delay={0.2}>
          <p className="mx-auto mt-8 max-w-xl leading-relaxed text-cream/70">
            Dis-nous où tu veux aller. On s'occupe du son qui t'y mène — du
            premier kick au master final.
          </p>
        </Reveal>

        <Reveal delay={0.3}>
          <div className="mt-12 flex flex-col items-center gap-6">
            <motion.a
              href="mailto:contact@elgorcreativhub.com"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex w-fit items-center gap-2.5 rounded-full bg-gold px-10 py-4.5 font-display text-sm font-bold uppercase tracking-widest text-ink transition-colors hover:bg-gold-soft"
            >
              Démarrer un projet
              <ArrowUpRight className="h-4 w-4" />
            </motion.a>
            <a
              href="mailto:contact@elgorcreativhub.com"
              className="inline-flex items-center gap-2 text-sm text-sand transition-colors hover:text-gold"
            >
              <Mail className="h-4 w-4" />
              contact@elgorcreativhub.com
            </a>
            <p className="text-[10px] uppercase tracking-[0.3em] text-sand/60">
              Réponse sous 24h — places limitées chaque mois
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
