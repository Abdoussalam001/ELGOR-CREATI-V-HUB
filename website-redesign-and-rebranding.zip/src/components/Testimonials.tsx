import { TESTIMONIALS } from "../data";
import { Reveal, SectionLabel } from "./Reveal";

export function Testimonials() {
  return (
    <section className="relative overflow-hidden py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <SectionLabel index="05" label="Ils en parlent" />
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-6 font-display font-black font-expanded uppercase leading-[0.9] tracking-tight md:text-5xl">
            Le son parle de lui-même
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.1} y={32} className="h-full">
              <figure className="flex h-full flex-col rounded-xl border border-line bg-coal p-7 transition-colors duration-500 hover:border-gold/40">
                <blockquote className="flex-1 leading-relaxed text-cream/80">
                  <span className="font-serif text-4xl italic block mb-3 opacity-60">
                    «
                  </span>
                  {t.quote}
                  <span className="font-serif text-4xl italic block mt-3 opacity-60">
                    »
                  </span>
                </blockquote>
                <figcaption className="mt-8 flex items-center gap-4 border-t border-line pt-6">
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gold/10 border border-gold/20 font-display text-sm font-bold text-gold">
                    {t.name.charAt(0)}
                  </span>
                  <div>
                    <p className="font-display text-sm font-bold">{t.name}</p>
                    <p className="text-xs text-sand">{t.role}</p>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
