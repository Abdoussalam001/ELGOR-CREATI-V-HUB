type MarkProps = { className?: string };

/**
 * Monogramme « EB » — reproduction vectorielle du logo Elgor.
 * Un E géométrique, quatre barres verticales (les « fils sonores »),
 * puis un B aux deux bowls. Tout est en currentColor.
 */
export function LogoMark({ className = "" }: MarkProps) {
  return (
    <svg
      viewBox="0 0 338 220"
      fill="currentColor"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      {/* --- E --- */}
      <path d="M0 0H130V42H70V89H112V131H70V178H130V220H0Z" />
      {/* --- Barres verticales --- */}
      <rect x="142" width="4" height="220" />
      <rect x="151" width="4" height="220" />
      <rect x="160" width="4" height="220" />
      <rect x="169" width="4" height="220" />
      {/* --- B --- */}
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M182 0H256C298 0 326 20 326 55C326 88 300 108 264 110C308 112 338 136 338 168C338 202 306 220 258 220H182V0ZM236 40H256C276 40 288 48 288 65C288 82 276 90 256 90H236V40ZM236 130H258C280 130 294 138 294 155C294 172 280 180 258 180H236V130Z"
      />
    </svg>
  );
}

type DotLetterProps = {
  letter?: string;
  className?: string;
  dotClassName?: string;
};

/**
 * Lettre du logo dont le contrepoin est remplacé par le point doré
 * signature (le « O » d'ELGOR). Le point hérite de la taille du texte :
 * 0.3em ≈ le contre d'un O en Archivo Black.
 */
export function DotLetter({
  letter = "O",
  className = "",
  dotClassName = "",
}: DotLetterProps) {
  return (
    <span className={`relative inline-block ${className}`}>
      {letter}
      <span
        className={`absolute left-1/2 top-[54%] h-[0.3em] w-[0.3em] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold ${dotClassName}`}
      />
    </span>
  );
}

type WordmarkProps = {
  className?: string;
  /** Ligne secondaire du wordmark */
  sub?: string;
};

/**
 * Bloc typographique du logo : « ELGOR » avec le point doré dans le O,
 * suivi de la ligne secondaire en tracking large.
 * Hérite de font-size : toute la brique se met à l'échelle d'un seul réglage.
 */
export function LogoWordmark({ className = "", sub = "Creati'v Hub" }: WordmarkProps) {
  return (
    <div className={`flex flex-col ${className}`}>
      <span className="flex items-baseline leading-[0.82] tracking-[-0.02em]">
        <span>ELG</span>
        <DotLetter />
        <span>R</span>
      </span>
      <span className="mt-[0.12em] text-[0.42em] font-bold uppercase tracking-[0.34em] text-gold">
        {sub}
      </span>
    </div>
  );
}

type LogoProps = {
  /** horizontal : monogramme à gauche du texte — stacked : monogramme au-dessus */
  layout?: "horizontal" | "stacked";
  className?: string;
  markClassName?: string;
};

export function Logo({
  layout = "horizontal",
  className = "",
  markClassName = "",
}: LogoProps) {
  if (layout === "stacked") {
    return (
      <div className={`flex flex-col items-center gap-[0.35em] ${className}`}>
        <LogoMark className="w-[2.1em]" />
        <LogoWordmark className="items-center text-center" />
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-[0.5em] ${className}`}>
      <LogoMark className={`w-[1.9em] shrink-0 ${markClassName}`} />
      <span className="h-[1.1em] w-px shrink-0 bg-current opacity-25" />
      <LogoWordmark />
    </div>
  );
}
