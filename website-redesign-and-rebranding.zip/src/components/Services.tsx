import { SERVICES } from "../data";
import { Reveal, SectionLabel } from "./Reveal";

export function Services() {
  return (
    <section id="services" className="relative py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <SectionLabel index="01" label="Services" />
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-6 font-display font-black font-expanded uppercase leading-[0.9] tracking-tight md:text-5xl">
            Un hub, quatre expertises
          </h2>
        </Reveal>

        <div className="mx-auto mt-16 max-w-6xl">
          <div className="border-t border-line">
            {SERVICES.map((service, i) => (
              <Reveal key={service.id} delay={i * 0.06} y={24}>
                <a
                  href="#contact"
                  className="group relative grid grid-cols-[auto_1fr_auto] items-center gap-5 border-b border-line px-2 py-8 transition-colors duration-300 hover:bg-coal md:gap-10 md:px-6 md:py-10"
                >
                  <span className="font-display text-sm font-bold text-sand transition-colors duration-300 group-hover:text-gold md:text-base">
                    {service.id}
                  </span>
                  <div>
                    <h3 className="font-display text-3xl font-bold font-expanded uppercase leading-none tracking-tight transition-colors duration-300 group-hover:text-gold md:text-5xl">
                      {service.title}
                    </h3>
                    <p className="mt-3 max-w-xl text-sm leading-relaxed text-sand md:text-base">
                      {service.description}
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {service.tags.map((tag) => (
                        <span
                          key={tag}
                          className="rounded-full border border-line px-3 py-1 text-[11px] font-medium uppercase tracking-widest text-sand transition-colors group-hover:border-gold/40 group-hover:text-cream/80"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                  <span className="text-[10px] font-medium uppercase tracking-widest text-sand transition-colors group-hover:text-gold">
                    Voir
                  </span>
                </a>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
