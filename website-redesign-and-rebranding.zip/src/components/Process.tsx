import { PROCESS } from "../data";
import { Reveal, SectionLabel } from "./Reveal";

export function Process() {
  return (
    <section id="processus" className="relative bg-coal py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <SectionLabel index="04" label="Processus" />
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-6 max-w-3xl font-display font-black font-expanded uppercase leading-[0.9] tracking-tight md:text-5xl">
            De l'idee au master
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-px overflow-hidden rounded-xl border border-line bg-line md:grid-cols-2 lg:grid-cols-4">
          {PROCESS.map((step, i) => (
            <Reveal key={step.n} delay={i * 0.1} y={28} className="h-full">
              <div className="group relative flex h-full flex-col bg-coal p-7 transition-colors duration-500 hover:bg-ink md:p-9">
                <span className="font-display text-5xl font-black font-expanded tracking-tight text-ink transition-colors duration-500 group-hover:text-gold md:text-6xl">
                  {step.n}
                </span>
                <h3 className="mt-6 font-display text-xl font-bold uppercase tracking-tight md:text-2xl">
                  {step.title}
                </h3>
                <p className="mt-4 text-sm leading-relaxed text-sand">
                  {step.desc}
                </p>
                <div className="mt-auto pt-6">
                  <div className="h-px w-full origin-left scale-x-0 bg-gold transition-transform duration-700 group-hover:scale-x-100"></div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
