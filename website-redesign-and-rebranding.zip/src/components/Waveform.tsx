type WaveformProps = {
  bars?: number;
  className?: string;
};

export function Waveform({ bars = 42, className = "" }: WaveformProps) {
  return (
    <div
      className={`flex h-14 items-end gap-[3px] ${className}`}
      aria-hidden="true"
    >
      {Array.from({ length: bars }).map((_, i) => (
        <span
          key={i}
          className="wave-bar"
          style={{
            height: `${18 + ((i * 53) % 82)}%`,
            animationDelay: `${(i % 13) * 0.09}s`,
            animationDuration: `${0.8 + (i % 6) * 0.15}s`,
          }}
        />
      ))}
    </div>
  );
}
