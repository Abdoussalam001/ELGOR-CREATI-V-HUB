import { TRACKS } from "../data";
import { Reveal, SectionLabel } from "./Reveal";

export function Tracks() {
  return (
    <section id="sons" className="relative bg-coal py-24 md:py-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <Reveal>
              <SectionLabel index="02" label="Sons" />
            </Reveal>
            <Reveal delay={0.1}>
              <h2 className="mt-6 font-display font-black font-expanded uppercase leading-[0.9] tracking-tight md:text-5xl">
                Dernieres sorties
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.2}>
            <p className="max-w-xs text-sm leading-relaxed text-sand">
              Une selection de beats prets a etre habités. Ecoute, choisis,
              cree — le reste, on s'en occupe.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-x-6 gap-y-12 sm:grid-cols-2 xl:grid-cols-4">
          {TRACKS.map((track, i) => (
            <Reveal key={track.title} delay={i * 0.08} y={32}>
              <a href="#contact" className="group block" data-cursor>
                <div className="relative aspect-square overflow-hidden rounded-xl border border-line">
                  <img
                    src={track.cover}
                    alt={`Pochette du beat ${track.title}`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100"></div>
                  <span className="absolute left-4 top-4 rounded-full bg-ink/80 px-3 py-1 text-[10px] font-medium uppercase tracking-widest text-cream/90 backdrop-blur-sm">
                    {track.genre}
                  </span>
                  <span className="absolute right-4 top-4 rounded-full border border-cream/20 bg-ink/80 px-3 py-1 text-[10px] font-medium tracking-widest text-gold backdrop-blur-sm">
                    {track.bpm} BPM
                  </span>
                </div>

                <div className="mt-5 flex items-start justify-between gap-4">
                  <div>
                    <h3 className="font-display text-lg font-bold tracking-tight">
                      <span className="mr-2 text-xs text-gold">0{i + 1}</span>
                      {track.title}
                    </h3>
                    <p className="mt-1 text-sm text-sand">
                      {track.genre} — {track.duration}
                    </p>
                  </div>
                  <span className="mt-1 text-[10px] font-medium uppercase tracking-widest text-sand transition-colors group-hover:text-gold">
                    Ecouter
                  </span>
                </div>

                <span className="mt-4 block h-px w-full origin-left scale-x-0 bg-gold transition-transform duration-700 ease-out group-hover:scale-x-100"></span>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
