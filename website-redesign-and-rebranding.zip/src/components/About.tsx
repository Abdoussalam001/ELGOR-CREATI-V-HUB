import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { STUDIO_IMAGE } from "../data";
import { Reveal, SectionLabel } from "./Reveal";

const POINTS = [
  "Producteur, compositeur et parolier — Gabon",
  "Collaborations : Waza No Limite, L'Oiseau Rare, FETTY NDOSS, CREOL",
  "Label : Gabon Music Entertainment (GME)",
  "Titres phares : TANTINE, TSE TSE BOH, Maligne, SOUND SYSTÈME",
];

export function About() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [-30, 30]);

  return (
    <section id="studio" className="relative overflow-hidden py-24 md:py-36">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 md:px-8 lg:grid-cols-2 lg:gap-24">
        <Reveal className="relative">
          <div ref={ref} className="relative">
            <div className="absolute -inset-3 rotate-2 rounded-2xl border border-gold/20" />
            <div className="relative overflow-hidden rounded-2xl border border-line">
              <motion.img
                src={STUDIO_IMAGE}
                alt="Studio d'enregistrement"
                style={{ y }}
                loading="lazy"
                className="aspect-[4/5] w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
            </div>
          </div>
        </Reveal>

        <div>
          <Reveal>
            <SectionLabel index="03" label="Le Hub" />
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="mt-6 font-display font-black font-expanded uppercase leading-[0.9] tracking-tight md:text-5xl">
              Elgor Creati'v Hub
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-8 leading-relaxed text-cream/70 max-w-lg">
              Producteur, compositeur et parolier basé au Gabon, Elgor façonne
              des beats qui frappent et des sons qui marquent. Au fil des
              années, il a accompagné des artistes tels que Waza No Limite,
              L'Oiseau Rare, FETTY NDOSS et CREOL, avec des titres comme
              TANTINE, TSE TSE BOH ou Maligne. Aujourd'hui, Elgor Creati'v Hub
              réunit production, mix, sound design et direction artistique sous
              un même toit.
            </p>
          </Reveal>
          <Reveal delay={0.3}>
            <p className="mt-4 leading-relaxed text-cream/70">
              Même exigence, même feu. Un pôle créatif pensé pour les artistes
              qui vont au bout de leur vision.
            </p>
          </Reveal>

          <Reveal delay={0.4}>
            <ul className="mt-10 space-y-4">
              {POINTS.map((point) => (
                <li key={point} className="flex items-start gap-4">
                  <span className="mt-[2px] block h-1 w-1 rounded-full bg-gold" />
                  <span className="text-sm text-cream/80">{point}</span>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={0.5}>
            <p className="mt-10 font-serif text-xl italic text-gold">
              — Elgor, fondateur & producteur
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
