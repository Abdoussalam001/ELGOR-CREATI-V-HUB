import { MARQUEE_ITEMS } from "../data";

function Row({ reverse = false, outline = false }: { reverse?: boolean; outline?: boolean }) {
  const content = MARQUEE_ITEMS.map((item, i) => (
    <span key={i} className="flex shrink-0 items-center gap-5 pr-5 md:gap-7 md:pr-7">
      <span
        className={`whitespace-nowrap font-display text-xl font-black font-expanded uppercase tracking-tight md:text-2xl ${
          outline ? "text-outline-thin" : "text-ink/85"
        }`}
      >
        {item}
      </span>
      <span className="h-3 w-px shrink-0 md:h-4 bg-current opacity-40" />
    </span>
  ));

  return (
    <div className={`flex w-max ${reverse ? "animate-marquee-reverse" : "animate-marquee"}`}>
      <div className="flex">{content}</div>
      <div className="flex" aria-hidden="true">
        {content}
      </div>
    </div>
  );
}

export function Marquee() {
  return (
    <section className="relative overflow-hidden py-12 md:py-16" aria-hidden="true">
      <div className="pause-on-hover rotate-[-1deg] bg-gold py-3 md:py-4">
        <Row />
      </div>
      <div className="pause-on-hover mt-4 rotate-[0.8deg] border-y border-gold/30 py-3 md:py-4">
        <Row reverse outline />
      </div>
    </section>
  );
}
