import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Reveal, SectionLabel } from "./Reveal";
import { X, Play } from "lucide-react";

type VideoItem = {
  id: string;
  title: string;
  channel: string;
  desc: string;
};

const YT_VIDEOS: VideoItem[] = [
  {
    id: "0FuINRL44_4",
    title: "L'Oiseau Rare Feat @ElgorBEATZ — SOUND SYSTÈME",
    channel: "L'Oiseau Rare 8G+",
    desc: "Clip officiel — production Elgor Beatz.",
  },
  {
    id: "IVS330tH4c0",
    title: "L'Oiseau Rare — SORRY I'M BAD",
    channel: "L'Oiseau Rare 8G+",
    desc: "Clip officiel — production Elgor Beatz.",
  },
  {
    id: "Fen4YRoXbkQ",
    title: "L'Oiseau Rare — CHAPILÉ",
    channel: "L'Oiseau Rare 8G+",
    desc: "Vidéo virale — production Elgor Beatz.",
  },
  {
    id: "_aDv8v7dKTU",
    title: "FETTY NDOSS feat. CREOL — LAISSEZ~MOI",
    channel: "FETTY NDOSS",
    desc: "Production Elgor Beatz.",
  },
  {
    id: "QtcD5S3ncls",
    title: "WAZA NO LIMITE x @ElgorBEATZ — TANTINE",
    channel: "Waza No Limite Officiel",
    desc: "Lyrics vidéo — production Elgor Beatz.",
  },
];

export function Immersion() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="immersion" className="relative bg-coal py-20 md:py-32 overflow-hidden">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <SectionLabel index="03" label="Immersion" />
        </Reveal>
        <Reveal delay={0.1}>
          <h2 className="mt-6 font-display font-black font-expanded uppercase leading-[0.9] tracking-tight md:text-5xl">
            Sessions en studio
          </h2>
        </Reveal>
        <Reveal delay={0.2}>
          <p className="mt-6 max-w-xl text-sm leading-relaxed text-sand md:text-base">
            Immersion dans les prods phares d’Elgor. Clips officiels, vidéos
            virales et sessions live — regarde le processus en direct.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {YT_VIDEOS.map((video, i) => (
            <Reveal key={video.id} delay={i * 0.08} y={32}>
              <article
                className="relative aspect-video overflow-hidden rounded-xl border border-line bg-ink transition-all duration-500 hover:border-gold/40 group cursor-pointer"
                onClick={() => setOpen(i)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter") setOpen(i);
                }}
              >
                <img
                  src={`https://i.ytimg.com/vi/${video.id}/hqdefault.jpg`}
                  alt={video.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute inset-0 flex items-end justify-between p-5">
                  <div>
                    <span className="inline-block mt-1 px-2 py-0.5 rounded border border-gold/30 bg-ink/80 text-[10px] font-medium uppercase tracking-widest text-gold">
                      {video.channel}
                    </span>
                    <h3 className="mt-2 font-display text-lg font-bold tracking-tight text-cream">
                      {video.title}
                    </h3>
                  </div>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/30 bg-ink/80 text-gold group-hover:bg-gold group-hover:text-ink transition-colors">
                    <Play className="h-5 w-5 ml-0.5" />
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {open !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm"
            onClick={() => setOpen(null)}
            onKeyDown={(e) => {
              if (e.key === "Escape") setOpen(null);
            }}
            role="dialog"
            aria-modal="true"
            aria-label="Lecture vidéo"
            tabIndex={-1}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="relative mx-auto mt-10 mb-10 max-w-5xl w-[90vw] aspect-video overflow-hidden rounded-2xl border border-gold/40 bg-ink shadow-2xl shadow-black/80"
            >
              <button
                onClick={() => setOpen(null)}
                className="absolute top-4 right-4 h-10 w-10 rounded-full border border-gold/40 bg-ink/80 text-gold hover:bg-gold hover:text-ink transition-colors z-20"
                aria-label="Fermer la vidéo"
              >
                <X className="h-5 w-5" />
              </button>
              <iframe
                className="h-full w-full"
                src={`https://www.youtube-nocookie.com/embed/${YT_VIDEOS[open].id}?autoplay=1&modestbranding=1&rel=0&showinfo=0&fs=1`}
                title={YT_VIDEOS[open].title}
                allow="accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                allowFullScreen
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent">
                <h3 className="font-display text-xl font-bold tracking-tight text-cream">
                  {YT_VIDEOS[open].title}
                </h3>
                <p className="mt-1 text-sm text-sand">{YT_VIDEOS[open].desc}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
