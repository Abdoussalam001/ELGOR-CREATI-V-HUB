import { ArrowUp } from "lucide-react";
import { NAV_LINKS, SERVICES, SOCIALS } from "../data";
import { LogoMark } from "./Logo";

function InstagramIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

function YoutubeIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  );
}

function XIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

const ICONS: Record<string, (p: { className?: string }) => React.ReactElement> = {
  Instagram: InstagramIcon,
  YouTube: YoutubeIcon,
  "X / Twitter": XIcon,
};

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-line bg-ink">
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-20 md:px-8">
        <a href="#top" className="group block" aria-label="Retour en haut">
          <LogoMark className="w-[clamp(110px,15vw,170px)] text-gold transition-colors duration-500 group-hover:text-gold-soft" />
          <div className="mt-7 font-display font-black uppercase leading-[0.82] tracking-[-0.02em]">
            <span className="block font-expanded text-[clamp(3rem,10vw,8rem)] leading-none">
              ELGOR
            </span>
            <span className="mt-2 block font-semi-expanded text-[clamp(1.5rem,5vw,3.8rem)] leading-[0.95] text-gold">
              Creati'v Hub
            </span>
          </div>
        </a>

        <div className="mt-18 grid gap-12 border-t border-line pt-14 md:grid-cols-[1.6fr_1fr_1fr_1fr]">
          <div>
            <p className="max-w-sm text-sm leading-relaxed text-sand">
              Studio de production musicale & pôle créatif. Des beats qui
              frappent, un son qui marque — de la première maquette au master
              final.
            </p>
            <div className="mt-7 flex gap-3">
              {SOCIALS.map((social) => {
                const Icon = ICONS[social.label];
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={social.label}
                    className="grid h-10 w-10 place-items-center rounded-full border border-line text-sand transition-colors hover:border-gold hover:text-gold"
                  >
                    <Icon className="h-4 w-4" />
                  </a>
                );
              })}
            </div>
          </div>

          <div>
            <p className="font-display text-xs font-bold uppercase tracking-[0.25em] text-gold">
              Navigation
            </p>
            <ul className="mt-6 space-y-3">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-sand transition-colors hover:text-cream"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-display text-xs font-bold uppercase tracking-[0.25em] text-gold">
              Services
            </p>
            <ul className="mt-6 space-y-3">
              {SERVICES.map((service) => (
                <li key={service.id}>
                  <a
                    href="#services"
                    className="text-sm text-sand transition-colors hover:text-cream"
                  >
                    {service.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-display text-xs font-bold uppercase tracking-[0.25em] text-gold">
              Contact
            </p>
            <ul className="mt-6 space-y-3 text-sm text-sand">
              <li>
                <a
                  href="mailto:contact@elgorcreativhub.com"
                  className="transition-colors hover:text-cream"
                >
                  contact@elgorcreativhub.com
                </a>
              </li>
              <li>Paris, France</li>
              <li>Réponse sous 24h</li>
            </ul>
            <a
              href="#top"
              className="mt-8 inline-flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.25em] text-sand transition-colors hover:text-gold"
            >
              Retour en haut
              <ArrowUp className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div className="mt-16 flex flex-col items-center justify-between gap-3 border-t border-line pt-10 text-xs text-sand md:flex-row">
          <p>
            © 2025 Elgor Creati'v Hub. Tous droits réservés.
          </p>
          <p className="font-serif text-sm italic text-gold/70">
            Conçu avec exigence, mixé avec passion.
          </p>
        </div>
      </div>
    </footer>
  );
}
