import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { Marquee } from "./components/Marquee";
import { Services } from "./components/Services";
import { Tracks } from "./components/Tracks";
import { Immersion } from "./components/Immersion";
import { About } from "./components/About";
import { Process } from "./components/Process";
import { Testimonials } from "./components/Testimonials";
import { CTA } from "./components/CTA";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-ink font-body text-cream">
      <Navbar />
      <main>
        <Hero />
        <Marquee />
        <Services />
        <Tracks />
        <Immersion />
        <About />
        <Process />
        <Testimonials />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
